drop schema public cascade;
create schema public;

ALTER SCHEMA public OWNER TO rafael;
