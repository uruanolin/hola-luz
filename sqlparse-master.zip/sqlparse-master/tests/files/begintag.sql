begin;
update foo
       set bar = 1;
commit;