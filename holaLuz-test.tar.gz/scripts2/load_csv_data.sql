COPY csv_perfils_inicials_i_demanda_referencia FROM '/home/u/Documents/holaLuz/myData/perfils_inicials_i_demanda_referencia.csv' DELIMITER ',' CSV;
COPY csv_demanda_sistema FROM '/home/u/Documents/holaLuz/myData/demanda_sistema.csv' DELIMITER ',' CSV;

--\copy csv_perfils_inicials_i_demanda_referencia from '/home/u/Documents/holaLuz/myData/perfils_inicials_i_demanda_referencia.csv' delimiter ',' csv;
--\copy csv_demanda_sistema from '/home/u/Documents/holaLuz/myData/demanda_sistema.csv' delimiter ';' csv;

--\copy csv_coeficients_ajust from '/home/u/Documents/holaLuz/myData/coeficients_ajust.csv' delimiter ',' csv;
