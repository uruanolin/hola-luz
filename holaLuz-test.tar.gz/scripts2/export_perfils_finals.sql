COPY perfils_finals TO '/home/u/Documents/holaLuz/perfils_finals.csv' DELIMITER ';' CSV HEADER;
